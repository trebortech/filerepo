YubiKey Smart Card Minidriver for Windows 4.0.4.164
===============================================================================
Release Date: February 13, 2019

These notes are published official releases only.  Interim version numbers are
reserved for external beta testing.

Version 4.0.4.164
-------------------------------------------------------------------------------
- Update PIV library to v1.6.4
- Support PIN_ALWAYS key usage policy via BaseCSP and Smart Card KSP
- Rewrite container synchronization to support certificate changes via external tools
- Smart card file system consistency fixes with changes made through other api functions
- Implements security fixes recommended by external review

Known Issues
-------------------------------------------------------------------------------
- The YubiKey NEO may freeze unexpectedly when trying to save large
  certificates.  The YubiKey NEO supports a max cert size of 2024 bytes.
- With YubiKey 4 certificate import, the MS certutil program may show an
  inconsistent number of certificates when the card has reached its maximum
  storage using the following command:
    certutil -key -csp "Microsoft Base Smart Card Crypto Provider"
- The Microsoft Base Smart Card Crypto Provider will not see any ECC
  certificates or keys. This is due to a limitation with the legacy CSP. To
  view ECC certificate and key information, you must use the Smart Card Key
  Storage Provider, ie: -csp "Microsoft Smart Card Key Storage Provider".
- The Microsoft Smart Card Key Storage Provider does not support import of ECC
  keys and certificates through the certutil program. This is a limitation of
  the certutil program.
- Windows 7 may not be able to verify code integrity of ykmd.dll due to the
  SHA256 signature applied by our code signing certificate. If you see a "Bad
  Image" warning when running certutil or see error 3002 in the
  Microsoft-Windows-CodeIntegrity-Operational log, apply the Microsoft security
  update KB3033929.
- If YKMD 3.3.1.5 was installed before YKMD 3.7, YKMD 3.3 is still visible in
  the Control Panel from either "Apps & features" or "Programs and Features"
  after upgrading to YKMD 3.7. Using the uninstall feature will remove the 
  application item.
- If a root certificate update results in a mscp/msroots file > 8kb, the file
  will be written to the PIV applet correctly, however, some versions of
  Windows will attempt to write the file to the SCard cache, resulting in
  a cache item too big error.

# Revision History

Version 4.0.0.162
-------------------------------------------------------------------------------
- Update PIV library to v1.6.2
- Remove implicit transactions on all commands sent to card, defer to CSP
- Support new YubiKey devices
- Adds CardAttestContainer extension to Smartcard Minidriver specification
- Resolves issues with root certificate update for large number of valid CA certs


Version 3.7.3.160
-------------------------------------------------------------------------------
- Update PIV library to v1.6.0
- Update release build to use VS 2017
- Fix certificate parse error if external tool adds blank cert objects
- Fix RSA key type interpolation from certificate in map synchronization
- Remove DefaultInstall logic from INF - MS has deprecated supplying both
  Manufacturer and DefaultInstall sections in HLK for Win10 1803.  Note because
  of this change, right-click install will no longer work on Windows 7 -- use
  the Device Manager to install or Windows Update.
- Remove MSI due to Microsoft deprecation of DiFX for Win8.1+


Version 3.7.0.152
-------------------------------------------------------------------------------

- Add CVE-2017-15361 (ROCA) mitigation on key generation
- Add FriendlyName to installer
- Direct install of UMPass service to mitigate HCK test issues on Win8.1
- Block PUK on MGM key upgrade if and only if it is default
- Always call SecureZeroMemory regardless of caller supplied allocator
- Implement PIN deauthentication without forcing a card reset
- Fix key container synchronization when keys are added through external apps
- Fix early transaction exit in some cases in PIV library
- Fix PIN unblock behavior
- Initial release for MSI

Version 3.3.1.5
----------------------------------------------------------------------

- First HDC certified release
- Many fixes to accommodate the HCK/HLK tests


Version 3.0
----------------------------------------------------------------------

- Full implementation of Minidriver v6 and v7.07 specification
- Full ECC support (P256/P384)
- Block PUK if PIV MGM key is default


Version 2.0
----------------------------------------------------------------------

- Full support for Windows Smart Card Credential Provider use cases
- Multiple PIV slot support


Version 1.0
----------------------------------------------------------------------

- Basic Minidriver Specification v7.07 implemented - BaseCSP use cases only
- Single PIV slot support only
- RSA (1024/2048) support only

(c) 2018 Yubico Inc. All Rights Reserved.